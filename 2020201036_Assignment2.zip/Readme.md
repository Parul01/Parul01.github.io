# Assignment 2


# Point 1
  - created a nav bar using `<div>`
  - used css to set its properties so it would come in all sections and stick to top.
  
# Point 2
  - Made 4 sections
  - `About me`
  - `Project`
  - `Diversions`
  - `Connect`

# Point 3
  - Given all sections bootstrap classes, and customized as required by overriding some properties with css.

  
# Point 4
  - Website hosted on `web.iiit.ac.in/~parul.ansal`
 
# Point 5
  - Using JQuery , a hidden section `Projects description` is displayed on hover.

# Point 6
  - used carousel to display hobbies.
 
# Point 7
  - Site has been madde in such a way that it is reponsive to different devices.




 


 

  
